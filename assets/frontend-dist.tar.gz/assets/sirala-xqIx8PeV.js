const n=new Intl.Collator("tr",{sensitivity:"base",numeric:!0});function o(t,r){return[...t].sort((e,i)=>n.compare(r(e)??"",r(i)??""))}export{o as m};
