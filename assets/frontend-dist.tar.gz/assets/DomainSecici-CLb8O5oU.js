const o="Select domain",s="No results",e={choose_domain:o,no_results:s};export{o as choose_domain,e as default,s as no_results};
