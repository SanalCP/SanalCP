const a="Sayfa yolu",t="Geri dön",c={path_label:a,back:t};export{t as back,c as default,a as path_label};
