const a="Page path",t="Go back",c={path_label:a,back:t};export{t as back,c as default,a as path_label};
