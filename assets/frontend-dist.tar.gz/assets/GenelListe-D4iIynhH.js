const e="Aramayla eşleşen kayıt yok.",a={no_search_results:e};export{a as default,e as no_search_results};
