const o="Alan adı seç",n="Sonuç yok",s={choose_domain:o,no_results:n};export{o as choose_domain,s as default,n as no_results};
