const e="No records match your search.",s={no_search_results:e};export{s as default,e as no_search_results};
